from flask import Flask, request, jsonify, render_template
import pickle
import torch

app = Flask(__name__)

# Load the model and tokenizer from the pickle file
with open("Model.pkl", "rb") as f:
    deployment_data = pickle.load(f)

# Map the model to CPU
model = deployment_data["model"].to(torch.device("cpu"))
tokenizer = deployment_data["tokenizer"]

@app.route("/")
def home():
    return render_template("index.html")  # Render the frontend page

@app.route("/convert", methods=["POST"])
def convert():
    # Get C code from the request
    c_code = request.json.get("code")

    # Tokenize the input C code
    inputs = tokenizer(c_code, return_tensors="pt", padding=True, truncation=True, max_length=512)

    # Generate the output (Python code)
    outputs = model.generate(**inputs, max_length=512)  # Increase max_length if needed

    # Decode the output tokens into text
    python_code = tokenizer.decode(outputs[0], skip_special_tokens=True)

    # Log the generated Python code
    print("Generated Python Code:", python_code)  # Debugging line

    # Return the Python code as a JSON response
    return jsonify({"python_code": python_code})

if __name__ == "__main__":
    app.run(debug=True)